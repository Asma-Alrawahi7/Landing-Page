## Project Summary

**Landing Page with Dynamic Navigation**

This project is a responsive landing page that features a dynamic navigation menu created using JavaScript. It includes four sections: Home, About Us, Our Services, and Contact Us. 

**How to Use:**

1. Clone the repository.
2. Open `index.html` in your web browser.
3. Use the menu to navigate between sections.

**Key Features:**

- Adapts to different screen sizes (desktop, tablet, mobile).
- Smoothly scrolls to sections when clicking navigation links.
- Highlights the active navigation link based on the current section.

**Getting Started:**

Just open the `index.html` file in your web browser to view the landing page.

**License:**

This project is licensed under the MIT License.
