// Function to dynamically create the navigation menu
function createNavbar() {
    const sections = ['home', 'about', 'services', 'contact'];
    const navList = document.getElementById('nav-list');

    sections.forEach(section => {
        const li = document.createElement('li');
        li.innerHTML = `<a href="#${section}">${section.charAt(0).toUpperCase() + section.slice(1)}</a>`;
        navList.appendChild(li);
    });
}

// Function to handle scroll behavior
function setupScroll() {
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('nav a');

    window.addEventListener('scroll', () => {
        sections.forEach(section => {
            const rect = section.getBoundingClientRect();
            if (rect.top >= 0 && rect.top < window.innerHeight) {
                navLinks.forEach(link => link.classList.remove('active'));
                document.querySelector(`nav a[href="#${section.id}"]`).classList.add('active');
            }
        });
    });

    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const targetId = event.target.getAttribute('href').substring(1);
            document.getElementById(targetId).scrollIntoView({ behavior: 'smooth' });
        });
    });
}

// Initialize the navbar and scroll behavior
createNavbar();
setupScroll();
